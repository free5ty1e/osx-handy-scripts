sudo apt-get update
sudo apt-get upgrade
sudo apt-get install -y xboxdrv
echo 'options bluetooth disable_ertm=Y' | sudo tee -a /etc/modprobe.d/bluetooth.conf
sudo reboot now
sudo bluetoothctl
Echo Review instructions to configure bluethoothctl before continuing
pause
REM Manually configure USB as follows
REM agent on
REM default-agent
REM scan on
REM connect YOUR_MAC_ADDRESS
REM trust YOUR_MAC_ADDRESS
sudo apt-get install joystick
Echo The next command is to test the connection only and is not needed unless you want to verify
pause
sudo jstest /dev/input/js0

